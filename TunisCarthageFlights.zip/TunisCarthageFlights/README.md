# TUNIS CARTHAGE FLIGHTS (Android, Kotlin + Jetpack Compose)

Arrivées et départs de l'aéroport Tunis-Carthage (TUN / DTTA) via **AeroDataBox**.

## Génération de l'APK
1. Ouvrir le dossier dans **Android Studio** (Koala ou plus récent, JDK 17) ; il télécharge Gradle et les dépendances.
   (En ligne de commande : `gradle wrapper` une fois, puis `./gradlew assembleDebug`.)
2. APK : `app/build/outputs/apk/debug/app-debug.apk`.
3. APK de release : configurer votre signature, puis `./gradlew assembleRelease`.

## Configuration de l'API (aucune clé n'est fournie)
- **Production recommandée : backend proxy.** Votre serveur détient la clé AeroDataBox et expose
  `GET {URL}/flights/airports/iata/TUN/{debut}/{fin}?direction=Both…` en renvoyant le JSON AeroDataBox.
  Saisir l'URL du proxy dans *Paramètres* ; aucune clé n'est alors nécessaire dans l'app.
- **Mode test :** coller votre clé RapidAPI dans *Paramètres*. Elle est stockée en clair sur l'appareil :
  **solution de développement uniquement**. Une clé embarquée dans un APK n'est jamais secrète.
- La clé n'est jamais journalisée ni affichée dans les messages d'erreur.

## Limites et couverture
- Fenêtre maximale de 12 h par requête (configurable 2–12 h, centrée sur l'heure actuelle, heure de Tunis).
- Bandeau : « Données en direct » seulement si l'API marque au moins un vol comme `Live` ; sinon
  « Horaires programmés uniquement ». Vérifiez la couverture réelle de TUN avec votre abonnement.
- Terminal, porte, comptoir, tapis : affichés uniquement s'ils sont fournis. Statut absent → « Statut indisponible ».
- Si l'API échoue : message d'erreur ; dernière réponse valide affichée avec « Données mises en cache », sinon liste vide.
- Respectez les quotas : l'actualisation auto est limitée à 2 min minimum.
- Mode démonstration : données fictives (DEMO…) clairement signalées, jamais utilisées en mode réel.
